package com.mycompany.step2eg;

public interface InputObserver {

    abstract void observerUpdate(char inputChar);
}
