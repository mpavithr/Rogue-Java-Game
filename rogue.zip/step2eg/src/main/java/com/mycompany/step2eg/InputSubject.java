package com.mycompany.step2eg;

public interface InputSubject {

    void registerInputObserver(InputObserver observer);
}
