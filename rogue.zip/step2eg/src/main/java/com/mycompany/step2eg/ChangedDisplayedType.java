package com.mycompany.step2eg;

public class ChangedDisplayedType extends CreatureAction {

    public ChangedDisplayedType(String name, Creature owner) {
        super(owner);
        System.out.println("ChangedDisplayedType constructor");
    }
}
