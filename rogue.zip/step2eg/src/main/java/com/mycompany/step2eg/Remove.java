package com.mycompany.step2eg;

public class Remove extends CreatureAction {

    public Remove(String name, Creature Owner) {
        super(Owner);
        System.out.println("Remove constructor");
    }
    
}
