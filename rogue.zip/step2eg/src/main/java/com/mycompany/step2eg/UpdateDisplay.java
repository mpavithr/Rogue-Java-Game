package com.mycompany.step2eg;

public class UpdateDisplay extends CreatureAction {

    public UpdateDisplay(String name, Creature owner) {
        super(owner);
        System.out.println("UpdateDisplay constructor");   
    }
}
