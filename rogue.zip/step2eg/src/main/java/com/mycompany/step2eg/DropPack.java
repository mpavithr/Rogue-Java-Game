package com.mycompany.step2eg;

public class DropPack extends CreatureAction {
    
    public DropPack(String name, Creature owner) {
        super(owner);
        System.out.println("DropPack constructor");
    }
    
}
