package com.mycompany.step2eg;

public class BlessCurseOwner extends ItemAction {
    
    public BlessCurseOwner(Item owner){
        super(owner, "BlessCurse Owner", "Item");
        System.out.println("BlessCurseOwner constructor");
    }
}
