package com.mycompany.step2eg;

public class EndGame extends CreatureAction {

    public EndGame(String name, Creature owner) {
        super(owner);
        System.out.println("EngGame constructor");
    }
}
