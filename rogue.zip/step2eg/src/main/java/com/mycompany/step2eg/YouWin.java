package com.mycompany.step2eg;

public class YouWin extends CreatureAction {

    public YouWin(String name, Creature owner) {
        super(owner);
        System.out.println("YouWin constructor");
    }
}
