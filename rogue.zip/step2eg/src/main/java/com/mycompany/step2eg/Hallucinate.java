package com.mycompany.step2eg;

public class Hallucinate extends ItemAction {

    public Hallucinate(Item owner) {
        super(owner, "Hallucinate", "Item");
        System.out.println("Hallucinate constructor");
    }
}
