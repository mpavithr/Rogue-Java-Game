package com.mycompany.step2eg;

public class Structure extends Displayable {
    
}
